// This file has no imports on purpose
// So it can easily be consumed by other TS projects
